#! /usr/bin/python3

#Created By:Lakshmi Deepita Pratti
#Date: 26-09-2019

#------------------To convert a gene sequence into protein sequence using the codon table----------------#


#----------------------------CREATING CODON TABLE-------------------------------------------#

protein= { 
        'ATT':'I', 'ATC':'I', 'ATA':'I', 'CTT':'L', 'CTC':'L', 'CTA':'L', 'CTG':'L', 'TTA':'L', 'TTG':'L', 
        'GTT':'V', 'GTC':'V', 'GTA':'V', 'GTG':'V','TTT':'F', 'TTC':'F','ATG':'M','TGT':'C', 'TGC':'C',
        'GCT':'A', 'GCC':'A', 'GCA':'A', 'GCG':'A','GGT':'G', 'GGC':'G', 'GGA':'G', 'GGG':'G',
        'CCT':'P', 'CCC':'P', 'CCA':'P', 'CCG':'P','ACT':'T', 'ACC':'T', 'ACA':'T', 'ACG':'T',
	'TCT':'S', 'TCC':'S', 'TCA':'S', 'TCG':'S','AGT':'S', 'AGC':'S','TAT':'Y', 'TAC':'Y',
	'TGG':'W','CAA':'Q', 'CAG':'Q','AAT':'N', 'AAC':'N','CAT':'H', 'CAC':'H','GAA':'E', 'GAG':'E',
	'GAT':'D', 'GAC':'D','AAA':'K', 'AAG':'K','CGT':'R', 'CGC':'R', 'CGA':'R', 'CGG':'R','AGA':'R', 'AGG':'R',             
        'TAA':'Stop', 'TAG':'Stop', 'TGA':'Stop'
    	}              

#---------------------------------File handling-----------------------------------------------#

seq = open('seq.txt')
gene = seq.readline()

print("Gene sequence =", "\n")
print(gene)
gene1 =list(gene)

length=len(gene1)

print("Output = ")
for i in range(0,length-3,3):
	amino=""
	for j in range(i,i+3):
		amino+=gene[j]             #Storing 3 Characters 
	for key,value in protein.items():
		if(amino==key):
			print(amino,"=",value)

seq.close()



#/usr/bin/python3 

#Created By: Lakshmi Deepita Pratti
#Date: 26-09-2019

#---------------TO CREATE A COUNT MATRIX OF GIVEN SEQUENCE OF NUMBERS FROM LIST-------------#

import numpy as np   
import pandas as pd

count_matrix = np.zeros((5, 5))    #To create a matrix of 5x5

list_num = [0, 1, 2, 3, 4, 1, 2, 3, 3, 1, 3, 0, 0, 2, 4, 1, 2, 1, 0, 0, 0, 2, 2, 2, 1, 1, 2, 3, 4, 4]
length = len(list_num)
print("List = ",list_num)

for i in range(0, length - 1):
    count_matrix[list_num[i]][list_num[i + 1]] = count_matrix[list_num[i]][list_num[i + 1]] + 1

print("Output = ")
print(pd.DataFrame(count_matrix, dtype=int))



#! /usr/bin/python

#Created By: Lakshmi Deepita Pratti
#Date: 1-Oct-2019

#---------------------STRING MANIPULATIONS---------------------#

string = "Lakshmi said, "
print("String = " , string)
length = len(string)
print("A) Length of string = ",length)

concat = string + "Ilovepython"
lengthcat= len(concat)
print("Concated string = ",concat)
print("B) Length of concated string = ",lengthcat)

num = input("Enter a number ")
catnum = concat+(num)*5
print("C) Concated string with number = ",catnum)

listeven = []
for i in range(len(catnum)):
    listeven.append(catnum[i])
listeven = listeven[::2]
print("D) Even indices characters of string are ",listeven)

convert = ""
convert = convert.join(listeven)
print("Convering list to string ",convert)
reverse = convert[::-1]
print("E) Reverse of the string = ", reverse)


replace = convert.replace(num,"a")
print("F) Replaced string with num for a = ",replace)


update = replace.upper()
print("G) Upper case string = ",update)



#! /usr/bin/python3

#Created By: Lakshmi Deepita Pratti
#Date: 1-Oct-2019

#------------------To determine the depth of the lake at point A------------#

nums = input("Enter height and length separated by Space: ")
h, l = map(int, nums.split())

if 1 <= h < l:
    depth = ((l * l) - (h * h)) / (2 * h)


print("Depth of lake at point A = %0.2f ",depth)

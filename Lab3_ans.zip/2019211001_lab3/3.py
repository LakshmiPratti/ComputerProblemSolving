#! bin/usr/python3

#Created By: Lakshmi Deepita Pratti
#Date: 1-Oct-2019

#--------------To create a G pattern-----------------------#

#NOTE: G pattern can't be made with number of rows less than 5 and G pattern will be unsymmetric with EVEN rows#

num = int(input("Enter Number: "))
if(num%2!=0):
    num_half = int(int(num)/2)
    i = 0
    while(i < 3):                                
        main_line = " " + '*' * num_half
        if(i == 0):
            print(" "+main_line)
            print(("*\n" * num_half).strip(), end ="")
        elif (i == 1):
            print(main_line)
            print(("*" + " " * num_half + "  *\n") * (num_half-1), end ="")
        else:
            print(" "+main_line)
        i += 1
else:
    print("Invalid Input")

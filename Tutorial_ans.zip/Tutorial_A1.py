#22/8/2019
#Tutorial Assignment, Question 2
#Created By: Lakshmi Deepita Pratti
#Roll no: 2019211001

#-----------------Creating pascal triangle using list----------------#

num = int(input("Enter number:  "))
arr_temp = [1] #Creating list
for i in range(num):
    arr = arr_temp
    print(arr)
    arr_temp = [arr[0]]
    for i in range(len(arr) - 1):
        arr_temp += [arr[i] + arr[i+1]]
    arr_temp += [arr[-1]]



#Tutorial Assignment, Question 1
#Created by: Lakshmi Deepita Pratti
#Roll no: 2019211001

#T---------------To print the nth term of Fibonacci Series---------------------------#

#----Defining a function fib which recieves the value of first two terms and the limit--------------------------------#

def fib(a,b,limit):
    for i in range(0,limit-2):
        ftemp = a + b
        a = b
        b = ftemp
    return ftemp

#-------------------------------------------------Main function-------------------------------------------------------#
num = int(input('Enter the range '))
x = 0
y = 1
if(num==1):
    print(0)
elif(num==2):
    print(1)
else:
    term = fib(x,y,num)                                       #Function calling
print("%dth term of Fibonacci Series is: %d" %(num,term))


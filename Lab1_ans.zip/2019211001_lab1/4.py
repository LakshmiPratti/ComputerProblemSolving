#! /usr/bin/python3

#Created By - Lakshmi Deepita Pratti

#To find AC% from given sequence of protein

import re

protein = open('seq.fasta','r')      #Opening the protein sequence file
text = protein.read()                #Reading the file
Count_A = 0                          #To count number of A's in sequence
Count_C = 0                          #To count number of C's in sequence
length =len(text)

for i in range(length-1):
    if('A'== text[i]):
        Count_A += 1
    elif('C' == text[i]):
        Count_C += 1

print("Number of A's are :", Count_A)
print("Number of C's are :", Count_C)

AC_per = round((((Count_A + Count_C)/length)* 100),3)

print("AC % of given sequence of protein is :",AC_per)



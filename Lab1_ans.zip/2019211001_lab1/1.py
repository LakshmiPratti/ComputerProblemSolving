#! /usr/bin/python

#Created by - Lakshmi Deepita Pratti

#Function to check whether the string is palindrome or not
#-----------------------------------------------------------------------#

def Palindrome(StringIn):
    String = StringIn.lower()         #converting whole string to lower case, we can do vice-versa too
    Reverse = ''                   #Taking the reverse of whole string
    length = len(String) - 1
    while(length>=0):
        Reverse = Reverse + String[length]
        length =length - 1
    if(Reverse == String):
        return 1

#-------------------------------MAIN CODE--------------------------------#

string1= str(input("Enter a String "))
Output = Palindrome(string1)
if(Output == 1):
    print(string1, "is a palindrome string")
else:
    print( string1, "is not palindrome string")

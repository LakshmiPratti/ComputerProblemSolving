#! bin/usr/python3

#Created By- Lakshmi Deepita Pratti

#Function to calculate the minimum, maximum and average speed of Srinath for each data set

def speed(lst):
    print(lst)
    less=1000
    more=0
    add=0
    for i in range(0,len(lst)):
        if(more<lst[i]):
            more=lst[i]
        if(less>lst[i]):
            less=lst[i]
        add=add+lst[i]
    length=len(lst)
    avg=round((add/length),3)
    print("Min=", less,"Max=", more, "Average=", avg)


#---------------------MAIN CODE---------------------------------------#
f = open('speed.txt')

line = f.readline()
while line:
    l = [int(n) for n in line.split()]
    speed(l)
    line = f.readline()
f.close()

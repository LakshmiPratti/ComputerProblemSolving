#! /usr/bin/python

#Created By - Lakshmi Deepita Pratti 

#Merging of two lists and creating a dictionary from it


list1 = ['a','b','c','d','e','f','g']
list2 = [1,2,3,4,5,6,7]
print("List1:  " , list1)
print("List2: ", list2)
merge =[]
for i in range(0,7):
    merge.append(list1[i])
    merge.append(list2[i])
print("Merged list: ", merge)

d = {}
for i in range(0, len(merge), 2):
    d.update({merge[i]:merge[i+1]})
print("Created dictionary: ", d)


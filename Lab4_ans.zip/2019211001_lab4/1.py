#! /usr/bin/python3

#Created by : Lakshmi Deepita Pratti
#Date : 31-Oct-2019

import re                  #Importing regex module
file = open("Megatrendsin2030.txt","r")
text = file.read()

                   #Extracting the subtitles from a file#

print("a:Extracted subtitles from the file are -\n")
for line in re.findall("\d+\.\s\w+\:|\d+\.\s\w+\s\w+\:",text):
    print(line)
print('\n')

          #Number of times the word ‘Megatrends’ is used in the file#
count= 0
count1= 0
count2 = 0
count3 = 0
for line in re.findall("Megatrends",text):
    if line:   
        count = count + 1
for line in re.findall("MegaTrends",text):
    if line:
        count1 = count1 + 1
for line in re.findall("megatrends",text):
    if line:
        count2 = count2 + 1
for line in re.findall("MegaTrends|Megatrends|megatrends",text):
    if line:
        count3 = count3 + 1
print("b:Number of times the word ‘Megatrends’ is used in the file is:",count)
print("b:Number of times the word ‘MegaTrends’ is used in the file is:",count1)
print("b:Number of times the word ‘megatrends’ is used in the file is:",count2)
print("b:Number of times the word ‘MegaTrends or Megatrends or megatrends’ is used in the file is:",count3)
print("\n")


              #Extracting the content enclosed in parenthesis#
print("c:Extracted content enclosed in parenthesis is - \n")
for line in re.findall("\((.*?)\)",text):
    print(line)
print("\n")

          #Extracting the years from file
print("d:Extracted years from file are -\n")
for line in re.findall("\d{4}",text):
    print(line)

file.close()

#! usr/bin/python3

#Created by: Lakshmi Deepita Pratti
#Date: 31-Oct-2019

import re

password = input("Enter your password:")
check = re.findall("^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,20}$",password)

if(check):
    print("Valid password")
else:
    print("Invalid password")

# 2. Find the LCM of two integers. Try to make the solution as efficient as possible.
#
# Input: num1 (int), num1 (int)
# Output: LCM (int).

import math

#---------------------------Defining a function to calculate the LCM of two integers----------------------------------#

def get_lcm(num1, num2):
    n1, n2 = num1, num2
    while num2 != 0:
        temp = num2
        num2 = num1 % num2
        num1 = temp
    hcf = num1
    lcm = (n1 * n2) / hcf
    return lcm

#-------------------------------------------Main Code --------------------------------------------------------------#
if __name__ == "__main__":
    num1 = int(input('Enter first integer '))
    num2 = int(input('Enter second integer  '))
    print(get_lcm(num1, num2))  #Calling of function
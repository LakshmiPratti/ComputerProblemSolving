# 5. For the above observatory, you decided to build a buckyball (truncated icosahedron) structure for the dome.
# Compute the amount of fabric required to cover the dome. You may assume that the  area is half that of the
# buckyball area.
#
# Input: radius (float in meters)
# Output: area (float with two decimal precision in sq. meters).

import math

#------------------------Defining the function to compute area required to cover the fabric------------------------#
def compute_area(radius):
    dome_area = 2 * math.pi * (radius**2)
    return round(dome_area)


#----------------------------MAIN CODE------------------------------------#
if __name__ == "__main__":
    radius_dome = float(input('Enter the radius '))
    print(compute_area(radius_dome))
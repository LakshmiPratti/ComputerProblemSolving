# 4. You are tasked with designing and building astronomical observatories for educational institutions. The
# observatories are circular shaped buildings with a hemispherical dome at the top. You are given the height, h,
# of the building measured from the ground to the apex of the dome and the radius, r or the building. Assuming that
# the dome height is at-most half of the total height of the building and that you ideally want a complete
# hemi-spherical dome, find the volume of the building.
#
# Input: height (float), radius (float)
# Output: volume (float with two decimal precision).

import math

#---------------------------------Defining a function to compute the volume of the building--------------------------#

def compute_vol(radius, height):
    dome_vol = (2 / 3) * math.pi * (radius**3)

    if radius == height:
        return dome_vol

    if height < radius:
        print("Height < Radius, not possible.")
        return None

#----------------------------------------MAIN CODE------------------------------------------------------------------#
if __name__ == "__main__":
    radius_obs = float(input('Enter the radius of dome '))
    height_obs =float(input('Height of the building '))
    print(compute_vol(radius_obs, height_obs))
# 1. Write a program to print all perfect squares between 1 and N (input).
#
# Input: N (int)
# Output: 1, 4, 9, ...

import math

#---------------Defining a function to calculate the perfect square between 1 and N--------------------------------#

def perfect_squares(num):
    squares = []
    while num >=1:
        if math.sqrt(num).is_integer():
            squares.append(num)
        num -= 1
    return squares

#---------------------------------------------Main code------------------------------------------------------------#
if __name__ == "__main__":
    per_sq = int(input('Enter the limit '))              #Calling of function
    print(perfect_squares(per_sq))
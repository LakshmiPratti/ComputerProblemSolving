# 3. You need to paint the walls and roof of a room that is shaped as a regular polygon with n sides,
# and side length, s. Find the cost of painting if it costs Rs. 12 to apply 1 coat of paint to 1 sq.meter of
# wall/roof, and you need to apply k coats of paint. Input units are in meters.
#
# Input: number of sides (int), length of 1 side (float), height of the room (float)
# Output: cost of painting (float with two decimal precision).

import math

#--------Defining the function that takes 3 parameters to calculate the total cost of painting walls/roof--------------#

def compute_cost(num_sides, len_side, height, num_coats):
    price_init = 12
    area_wall = len_side * height
    total_wall_area = area_wall * num_sides
    total_roof_area = len_side / (2 * math.tan(180 / num_sides))
    total_roof_area = (len_side * num_sides * total_roof_area) / 2
    total_area = total_wall_area + total_roof_area
    total_cost = price_init * num_coats * total_area
    return total_cost

#-------------------------------------MAIN CODE------------------------------------------------------------------#
if __name__ == "__main__":
    num_sides= int(input('Enter the number of sides '))
    len_side= float(input('Enter the length of one side '))
    height= float(input('Enter the height '))
    num_coats= int(input('Enter the number of coats '))
    t_cost = compute_cost(num_sides, len_side, height, num_coats)#----------------Calling of function----------------------#
    print("%.2f" %t_cost)
